﻿// Xml Visualizer v.2
// by Lars Hove Christiansen (larshove@gmail.com)
// http://www.codeplex.com/XmlVisualizer

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Xml Visualizer v.2")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Lars Hove Christiansen")]
[assembly: AssemblyProduct("Xml Visualizer v.2")]
[assembly: AssemblyCopyright("Copyright © Lars Hove Christiansen")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("c71e4664-eacf-424c-b5f0-be2e1aa48d50")]

[assembly: AssemblyVersion("6.3.0.0")]
[assembly: AssemblyFileVersion("6.3.0.0")]
