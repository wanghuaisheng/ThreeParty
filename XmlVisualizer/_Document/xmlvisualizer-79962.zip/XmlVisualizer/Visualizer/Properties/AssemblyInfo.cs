﻿// Xml Visualizer v.2
// by Lars Hove Christiansen (larshove@gmail.com)
// http://www.codeplex.com/XmlVisualizer

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Xml Visualizer v.2")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Lars Hove Christiansen")]
[assembly: AssemblyProduct("Xml Visualizer v.2")]
[assembly: AssemblyCopyright("Copyright © Lars Hove Christiansen")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("e25dd143-aeea-4bf3-8e0c-1876b1d600b5")]

[assembly: AssemblyVersion("6.3.0.0")]
[assembly: AssemblyFileVersion("6.3.0.0")]
