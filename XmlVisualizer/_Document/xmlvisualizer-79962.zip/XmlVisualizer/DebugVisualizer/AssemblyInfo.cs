﻿// Xml Visualizer v.2
// by Lars Hove Christiansen (larshove@gmail.com)
// http://www.codeplex.com/XmlVisualizer

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Xml Visualizer v.2")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Lars Hove Christiansen")]
[assembly: AssemblyProduct("Xml Visualizer v.2")]
[assembly: AssemblyCopyright("Copyright © Lars Hove Christiansen")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("9f0bcefc-513a-449c-9c62-dce8ba1a8930")]

[assembly: AssemblyVersion("6.3.0.0")]
[assembly: AssemblyFileVersion("6.3.0.0")]

[assembly: System.Diagnostics.DebuggerVisualizer(
    typeof(XmlVisualizer.DebugVisualizer),
    typeof(Microsoft.VisualStudio.DebuggerVisualizers.VisualizerObjectSource),
    Target = typeof(System.String),
    Description = "XML Visualizer v.2")]
