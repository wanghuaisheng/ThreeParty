﻿
namespace KellermanSoftware.CompareNetObjectsTests.TestClasses
{
    public enum Deck 
    {
        Engineering,
        SickBay,
        AstroPhysics
    }
}
