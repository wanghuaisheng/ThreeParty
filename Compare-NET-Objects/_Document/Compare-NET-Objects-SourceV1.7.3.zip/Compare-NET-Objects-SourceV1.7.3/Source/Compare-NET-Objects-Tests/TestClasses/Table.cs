﻿using System;

namespace KellermanSoftware.CompareNetObjectsTests.TestClasses
{
    public class Table
    {
        public string TableName { get; set; }
        public Type ClassType { get; set; }
    }
}
