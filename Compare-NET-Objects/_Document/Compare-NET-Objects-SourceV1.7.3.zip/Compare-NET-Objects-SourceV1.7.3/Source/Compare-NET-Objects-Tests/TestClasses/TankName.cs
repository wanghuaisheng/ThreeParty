﻿namespace KellermanSoftware.CompareNetObjectsTests.TestClasses
{
    public class TankName
    {
        public string FamilyName;
        public string GivenName;
    }
}
