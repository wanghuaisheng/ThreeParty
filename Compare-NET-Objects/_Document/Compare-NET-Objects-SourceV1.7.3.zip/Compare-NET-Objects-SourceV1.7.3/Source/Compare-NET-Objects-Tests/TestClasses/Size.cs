﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KellermanSoftware.CompareNetObjectsTests.TestClasses
{
    public struct Size
    {
        public int Width;
        public int Height;
    }
}
