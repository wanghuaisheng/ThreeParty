﻿using System;

namespace KellermanSoftware.CompareNetObjectsTests.TestClasses
{
    public class TankPerson
    {
        public int Id;
        public TankName Name;
        public DateTime DateCreated;
        public string Address;
    }
}
