﻿namespace KellermanSoftware.CompareNetObjectsTests.TestClasses
{
    public class HashSetClass
    {
        public int Id { get; set; }
    }
}
