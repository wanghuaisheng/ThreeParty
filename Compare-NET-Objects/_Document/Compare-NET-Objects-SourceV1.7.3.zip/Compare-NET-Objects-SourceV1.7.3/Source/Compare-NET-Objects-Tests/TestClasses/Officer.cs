﻿namespace KellermanSoftware.CompareNetObjectsTests.TestClasses
{
    public class Officer
    {
        public string Name { get; set; }
        public Deck Type { get; set; }
    }
}
