﻿namespace KellermanSoftware.CompareNetObjectsTests.TestClasses
{
    public interface ILabTestAlias
    {
        string LabTestAlias
        {
            get;
            set;
        }
        System.Guid LabTestAliasId
        {
            get;
            set;
        }
        System.Guid LabTestId
        {
            get;
            set;
        }
    }
}
